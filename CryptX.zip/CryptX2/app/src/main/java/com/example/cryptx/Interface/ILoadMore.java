package com.example.cryptx.Interface;

public interface ILoadMore {
    void onLoadMore();
}
